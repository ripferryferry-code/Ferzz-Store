-- FERZZ STORE - Auto Fully Loader
-- GitHub hanya menyimpan loader ini.

local SOURCE_URL = "https://GANTI-DOMAIN-SERVER-KAMU/api/source/auto-fully"

local ok, body = pcall(function()
    return game:HttpGet(SOURCE_URL)
end)

if not ok then
    warn("[FERZZ STORE] Gagal mengambil Auto Fully: " .. tostring(body))
    return
end

local fn, err = loadstring(body)
if not fn then
    warn("[FERZZ STORE] Source tidak valid: " .. tostring(err))
    return
end

local runOk, runErr = pcall(fn)
if not runOk then
    warn("[FERZZ STORE] Auto Fully error: " .. tostring(runErr))
end
