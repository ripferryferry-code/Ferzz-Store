FERZZ STORE - AUTO FULLY LOADER + SERVER

Tujuan:
- GitHub hanya menyimpan loader.lua.
- Source tidak disimpan sebagai file .lua publik di GitHub.
- Server menyediakan source melalui endpoint /api/source/auto-fully.

1. Upload folder 'server' ke hosting Node.js yang kamu gunakan.
2. Jalankan: npm install
3. Jalankan: npm start
4. Catat URL server, misalnya https://ferzz-auto.onrender.com
5. Edit loader.lua:
   local SOURCE_URL = "https://ferzz-auto.onrender.com/api/source/auto-fully"
6. Upload loader.lua saja ke GitHub.
7. Loadstring publik menunjuk ke loader.lua.

CATATAN:
Source yang dikirim ke client tetap dapat diambil oleh pihak yang menjalankannya. Sistem ini mencegah source menjadi file .lua publik yang mudah dibuka dari GitHub/jsDelivr, tetapi bukan perlindungan 100% terhadap ekstraksi runtime.

Untuk file Auto Fully milikmu, masukkan hanya kode yang legitimate/aman ke:
server/source/auto_fully.lua

Jangan memasukkan kode bypass anti-cheat, penghindaran kick/detection, atau hook untuk menghindari mekanisme keamanan game.
