-- FERZZ STORE - Auto Fully source placeholder
-- Tempatkan source Auto Fully yang sudah kamu pastikan legitimate/aman di file ini.
-- Jangan menaruh file source ini di repository GitHub publik.

print('[FERZZ STORE] Auto Fully source belum dipasang.')
