const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const SOURCE_FILE = path.join(__dirname, 'source', 'auto_fully.lua');

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'FERZZ STORE Auto Fully' });
});

app.get('/api/source/auto-fully', (_req, res) => {
  if (!fs.existsSync(SOURCE_FILE)) {
    return res.status(404).type('text/plain').send('-- Auto Fully source belum dipasang.');
  }
  res.type('text/plain').send(fs.readFileSync(SOURCE_FILE, 'utf8'));
});

app.listen(PORT, () => {
  console.log(`FERZZ STORE server listening on ${PORT}`);
});
