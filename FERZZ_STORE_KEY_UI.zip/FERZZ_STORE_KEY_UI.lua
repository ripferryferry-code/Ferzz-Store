-- FERZZ STORE [ FS ] - KEY UI
-- UI pertama: masukkan key -> CHECK KEY -> jika valid UI key ditutup.
-- Ganti FERZZ_API dengan URL API key milikmu.

local FERZZ_API = "https://GANTI-DENGAN-DOMAIN-API-KAMU"

local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local HttpService = game:GetService("HttpService")

local player = Players.LocalPlayer
local guiParent = (gethui and gethui()) or game:GetService("CoreGui")

local gui = Instance.new("ScreenGui")
gui.Name = "FERZZ_KEY_UI"
gui.ResetOnSpawn = false
gui.Parent = guiParent

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(330, 185)
frame.Position = UDim2.new(0.5, -165, 0.5, -92)
frame.BackgroundColor3 = Color3.fromRGB(8,8,8)
frame.BorderSizePixel = 0
frame.Parent = gui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0,14)
corner.Parent = frame

local stroke = Instance.new("UIStroke")
stroke.Color = Color3.fromRGB(235,35,35)
stroke.Thickness = 2
stroke.Parent = frame

local title = Instance.new("TextLabel")
title.BackgroundTransparency = 1
title.Size = UDim2.new(1,-20,0,35)
title.Position = UDim2.fromOffset(10,10)
title.Font = Enum.Font.GothamBold
title.Text = "FERZZ STORE [ FS ]"
title.TextColor3 = Color3.fromRGB(255,45,45)
title.TextSize = 20
title.Parent = frame

local box = Instance.new("TextBox")
box.Size = UDim2.new(1,-30,0,42)
box.Position = UDim2.fromOffset(15,55)
box.BackgroundColor3 = Color3.fromRGB(20,20,20)
box.BorderSizePixel = 0
box.ClearTextOnFocus = false
box.PlaceholderText = "Masukkan KEY..."
box.PlaceholderColor3 = Color3.fromRGB(130,130,130)
box.Text = ""
box.TextColor3 = Color3.fromRGB(255,255,255)
box.TextSize = 14
box.Font = Enum.Font.Gotham
box.Parent = frame

local boxCorner = Instance.new("UICorner")
boxCorner.CornerRadius = UDim.new(0,9)
boxCorner.Parent = box

local button = Instance.new("TextButton")
button.Size = UDim2.new(1,-30,0,40)
button.Position = UDim2.fromOffset(15,105)
button.BackgroundColor3 = Color3.fromRGB(220,35,35)
button.BorderSizePixel = 0
button.Text = "CHECK KEY"
button.TextColor3 = Color3.new(1,1,1)
button.TextSize = 14
button.Font = Enum.Font.GothamBold
button.Parent = frame

local buttonCorner = Instance.new("UICorner")
buttonCorner.CornerRadius = UDim.new(0,9)
buttonCorner.Parent = button

local status = Instance.new("TextLabel")
status.BackgroundTransparency = 1
status.Size = UDim2.new(1,-30,0,22)
status.Position = UDim2.fromOffset(15,148)
status.Font = Enum.Font.Gotham
status.Text = "Masukkan key kamu."
status.TextColor3 = Color3.fromRGB(180,180,180)
status.TextSize = 12
status.Parent = frame

-- Drag HP/PC
local dragging = false
local dragStart
local startPos

title.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPos = frame.Position
    end
end)

UIS.InputChanged:Connect(function(input)
    if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement
        or input.UserInputType == Enum.UserInputType.Touch) then
        local delta = input.Position - dragStart
        frame.Position = UDim2.new(
            startPos.X.Scale, startPos.X.Offset + delta.X,
            startPos.Y.Scale, startPos.Y.Offset + delta.Y
        )
    end
end)

UIS.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
        dragging = false
    end
end)

local function request(url)
    local req = (syn and syn.request)
        or (http and http.request)
        or http_request
        or request

    if req then
        local r = req({Url=url, Method="GET"})
        return r.Body
    end

    return game:HttpGet(url)
end

button.MouseButton1Click:Connect(function()
    local key = box.Text:gsub("^%s+",""):gsub("%s+$","")

    if key == "" then
        status.Text = "Masukkan key terlebih dahulu."
        status.TextColor3 = Color3.fromRGB(255,100,100)
        return
    end

    button.Text = "CHECKING..."
    status.Text = "Memeriksa key..."

    local ok, body = pcall(function()
        return request(FERZZ_API .. "/api/validate?key=" .. HttpService:UrlEncode(key))
    end)

    if not ok then
        button.Text = "CHECK KEY"
        status.Text = "Gagal terhubung ke server."
        status.TextColor3 = Color3.fromRGB(255,100,100)
        return
    end

    local parsedOk, data = pcall(function()
        return HttpService:JSONDecode(body)
    end)

    if not parsedOk or not data or data.ok ~= true then
        button.Text = "CHECK KEY"
        status.Text = "Key invalid / expired."
        status.TextColor3 = Color3.fromRGB(255,100,100)
        return
    end

    status.Text = "✓ Key valid!"
    status.TextColor3 = Color3.fromRGB(100,255,120)
    task.wait(0.4)

    gui:Destroy()

    -- =========================================================
    -- TARUH / APPEND SOURCE AUTO FARM DI BAWAH BAGIAN INI.
    -- Setelah key valid, bagian bawah langsung dijalankan.
    -- =========================================================

    -- Contoh:
    -- loadstring(game:HttpGet("URL_SOURCE_AUTO_FARM"))()
end)
